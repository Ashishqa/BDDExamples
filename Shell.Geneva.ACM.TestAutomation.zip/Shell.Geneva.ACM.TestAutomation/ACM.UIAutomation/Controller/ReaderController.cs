﻿using System;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using ACM.UIAutomation.Helper.Readers;

namespace ACM.UIAutomation.Controller
{
    public class ReaderController
    {
       
        public async Task<ConcurrentDictionary<string, dynamic>> ReadExcelData(string scenarioName, string sheetName, string excelDataFilePath)
        {

            return await Task.Run(() => new ExcelReader().GetExcelDataCollection(scenarioName, sheetName,excelDataFilePath));
        }
        public async Task<ConcurrentDictionary<string, dynamic>> ReadJasonData(string scenarioName, string jsonFilePath)
        {

            return await Task.Run(() => new JsonReader().GetJsonDataCollection(scenarioName, jsonFilePath));
        }


    }
}
