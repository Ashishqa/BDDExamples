﻿using System;
using System.Collections.Generic;
using System.Text;
using ACM.UIAutomation.Handler;
using OpenQA.Selenium;

namespace ACM.UIAutomation.Controller
{
    public class DriverController
    {
        private readonly ChromeDriverHandler chromeDriverHandler = new ChromeDriverHandler();
        public IWebDriver ChromeDriver()
        {
            return chromeDriverHandler.GetCromeDriver(); 
        }
        public IWebDriver FireFoxDriver()
        {
            return null;
        }
        public IWebDriver EdgeDriver()
        {
            return null;
        }
    }
}
