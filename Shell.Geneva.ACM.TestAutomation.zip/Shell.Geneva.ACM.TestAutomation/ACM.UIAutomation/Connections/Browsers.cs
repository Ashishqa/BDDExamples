﻿using ACM.UIAutomation.Model.AppSettings;

namespace ACM.UIAutomation.Connections
{
    public class Browsers
    {
        public static string Browser { get; set; } = GetBrowserBy("Browser");

        private static string GetBrowserBy(string BrowserConfigKey)
        {
            return AppSettings.GetValue<string>($"EndPoint:{BrowserConfigKey}");
        }
    }
}
