﻿using ACM.UIAutomation.Model.AppSettings;

namespace ACM.UIAutomation.Connections
{
    public class EndPoints
    {
        public static string Url { get; set; } = GetEndPointBy("Url");

        private static string GetEndPointBy(string EndPointConfigKey)
        {
            return AppSettings.GetValue<string>($"EndPoints:{EndPointConfigKey}");
        }

    }
}
