﻿using static ACM.UIAutomation.Helper.Paths;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace ACM.UIAutomation.Handler
{
    public class ChromeDriverHandler
    {
        public IWebDriver GetCromeDriver()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("--start-maximized");
            return new ChromeDriver(ChromeDriverPath, options);
        }

    }
}
