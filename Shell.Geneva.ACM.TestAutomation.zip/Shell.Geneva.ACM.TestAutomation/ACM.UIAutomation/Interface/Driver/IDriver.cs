﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;

namespace ACM.UIAutomation.Interface.Driver
{
    public interface IDriver
    {
        public IWebDriver GetDriver();
    }
}
