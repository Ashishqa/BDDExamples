﻿using ACM.UIAutomation.Controller;
using OpenQA.Selenium;

namespace ACM.UIAutomation.Interface.Driver
{
    class FireFoxDriver : IDriver
    {
        private readonly DriverController driverController = new DriverController();

        public IWebDriver GetDriver()
        {
            return driverController.FireFoxDriver();
        }
    }
}

