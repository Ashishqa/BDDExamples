﻿using System;
using System.Collections.Generic;
using System.Text;
using ACM.UIAutomation.Controller;
using OpenQA.Selenium;

namespace ACM.UIAutomation.Interface.Driver
{
    public class EdgeDriver  : IDriver
    {
        private readonly DriverController driverController = new DriverController();

        public IWebDriver GetDriver()
        {
            return driverController.EdgeDriver();
        }
    }
}
