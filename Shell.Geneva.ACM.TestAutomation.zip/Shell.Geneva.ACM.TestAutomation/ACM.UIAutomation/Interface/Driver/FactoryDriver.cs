﻿using System;
using System.Collections.Generic;
using System.Text;
using ACM.UIAutomation.Helper;

namespace ACM.UIAutomation.Interface.Driver
{
    public class FactoryDriver
    {
        public IDriver Factory(Browsers browser)
        {
            dynamic driver = null;
            switch(browser)
            {
                case Browsers.Chrome:
                    driver= new ChromeDiver();
                    break;
                case Browsers.FireFox:
                    driver= new FireFoxDriver();
                    break;
                case Browsers.Edge:
                    driver= new EdgeDriver();
                    break;
            }
            return driver;
        }
    }
}
