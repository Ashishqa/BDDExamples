﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ACM.UIAutomation.Helper;

namespace ACM.UIAutomation.Interface.Readers
{
    public interface IReader
    {
        static string Country { get; }
        static string City { get; }
        static string Owners { get; }
        static string AssetType { get; }
        static string Assets { get; }
        static string UnitType { get; }
        static string UnitSubType { get; }
        static string Unit { get; }

        Task<dynamic> LoadConfigurationExcel(string scenarioName, string sheetName = "Shell.ACM.UiAutomation.TestData", string excelDataFilePath = null);
        Task<dynamic> LoadConfigurationJson(string scenarioName, string jsonFilePath=null);
    }
}
