﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ACM.UIAutomation.Controller;
using ACM.UIAutomation.Interface.Readers;

namespace ACM.UIAutomation.Interface.Reader
{
    public class Reader : IReader
    {
        private static ConcurrentDictionary<string, dynamic> _configurationData = new ConcurrentDictionary<string, dynamic>();
        private readonly ReaderController readerController = new ReaderController();

        public static string Country => _configurationData["Country"];

        public static string City => _configurationData["City"];

        public static string Owners => _configurationData["Owners"];

        public static string AssetType => _configurationData["AssetType"];

        public static string Assets => _configurationData["Assets"];

        public static string UnitType => _configurationData["UnitType"];

        public static string UnitSubType => _configurationData["UnitSubType"];

        public static string Unit => _configurationData["Unit"];

       
        public async Task<dynamic> LoadConfigurationExcel(string scenarioName, string sheetName, string excelDataFilePath)
        {
            _configurationData= await readerController.ReadExcelData(scenarioName, sheetName, excelDataFilePath);
            return _configurationData;
        }

        public async Task<dynamic> LoadConfigurationJson(string scenarioName, string jsonFilePath)
        {
            _configurationData.Clear();
            _configurationData = await readerController.ReadJasonData(scenarioName, jsonFilePath);
            return _configurationData;
        }
    }
}
