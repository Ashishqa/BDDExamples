﻿using System;
using System.Collections.Generic;
using System.Text;
using ACM.UIAutomation.Interface.DataBase;
using ACM.UIAutomation.Interface.Driver;
using ACM.UIAutomation.Interface.Readers;
using ACM.UIAutomation.Interface.Setup;

namespace ACM.UIAutomation.Interface.Reference
{
    public class AcmReference
    {
        public IReader Reader => new Reader.Reader();
        public IExecuteDBQuries ExecuteDBQuries => new ExecuteDBQuries();

        public ISetup Setup => new SetUp();
    }
}
