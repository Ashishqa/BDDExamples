﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ACM.UIAutomation.Helper;

namespace ACM.UIAutomation.Interface.Setup
{
    public interface ISetup
    {
        Task Initialize(Browsers browser = Browsers.Chrome);
    }
}
