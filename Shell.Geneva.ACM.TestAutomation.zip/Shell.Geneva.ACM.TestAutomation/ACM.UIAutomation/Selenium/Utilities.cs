﻿using System;
using System.Collections.Generic;
using System.Text;
using OpenQA.Selenium;

namespace ACM.UIAutomation.Selenium
{
    public class Utilities
    {
       private static IWebDriver WebDriver = Driver.getDriver;
        public static void LaunchUrl(string url)
        {
            WebDriver.Url = url;
            WebDriver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(120);
        }
    }
}
