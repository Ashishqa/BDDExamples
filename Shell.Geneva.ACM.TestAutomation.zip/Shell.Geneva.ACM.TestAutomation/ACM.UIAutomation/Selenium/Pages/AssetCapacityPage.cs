﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using ExpectedConditions = OpenQA.Selenium.Support.UI.ExpectedConditions;

namespace ACM.UIAutomation.Selenium.Pages
{
    public class AssetCapacityPage
    {
        public static IWebDriver WebDriver = Driver.getDriver;
        public WebDriverWait WebDriverWait;
        public AssetCapacityPage(int waitInMilliSecond = 90)
        {
            WebDriverWait = new WebDriverWait(WebDriver, TimeSpan.FromSeconds(waitInMilliSecond));
        }

        //public IWebElement ProgramMenu => WebDriver.FindElement(By.XPath("//aside/ul/li[2]"));
        //public IWebElement CapacityTotal => WebDriver.FindElement(By.XPath("//*[contains(text(),'Capacity - Total')]"));
        //public IWebElement AssetCapacity => WebDriver.FindElement(By.XPath("//*[contains(text(),'Asset Capacity')]"));
        // public IWebElement Filter => WebDriver.FindElement(By.XPath("//*[@class='k-icon k-i-filter k-icon']"));
        //public IWebElement Search_Country => WebDriver.FindElement(By.XPath("//*[@Id='country-search-box']"));
        //public IWebElement Search_City => WebDriver.FindElement(By.XPath("//*[@Id='city-search-box']"));
        //public IWebElement Search_Company => WebDriver.FindElement(By.XPath("//*[@id='company - search - box']"));
        //public IWebElement Search_AssetType => WebDriver.FindElement(By.XPath("//*[@Id='assetClass-search-box']"));
        //public IWebElement Search_Assets => WebDriver.FindElement(By.XPath("//*[@Id='asset-search-box']"));
        //public IWebElement Search_UnitType => WebDriver.FindElement(By.XPath("//*[@Id='unitType-search-box']"));
        //public IWebElement Search_UnitSubType => WebDriver.FindElement(By.XPath("//*[@Id='unitSubType-search-box']"));
        //public IWebElement Search_Unit => WebDriver.FindElement(By.XPath("//*[@Id='unit-search-box']"));
        //public IWebElement Apply_Button => WebDriver.FindElement(By.XPath("//*[@class='reset-clear apply']"));
        public IWebElement Unit => WebDriver.FindElement(By.XPath("//*[@class='k-button k-primary btn border k-group-end']"));

        public void ClickProgramMenu()
        {
            var ProgramMenu = WebDriver.FindElement(By.XPath("//aside/ul/li[2]"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(ProgramMenu));
            ProgramMenu.Click();
        }

        public void ClickCapacityTotal()
        {
            var CapacityTotal = WebDriver.FindElement(By.XPath("//*[contains(text(),'Capacity - Total')]"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(CapacityTotal));
            CapacityTotal.Click();
        }

        public string GetAssetCapacityText()
        {
            var AssetCapacity = WebDriver.FindElement(By.XPath("//*[contains(text(),'Asset Capacity')]"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(AssetCapacity));
            return AssetCapacity.Text;
        }

        public void ClickFilter()
        {
            var Filter = WebDriver.FindElement(By.XPath("//*[@class='k-icon k-i-filter k-icon']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Filter));
            Filter.Click();
        }

        public void ClickSearchCountry()
        {
            var Search_Country = WebDriver.FindElement(By.XPath("//*[@Id='country-search-box']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_Country));
            Search_Country.Click();
        }

        public void SelectCountryFromList(string country)
        {
            SelectCheckBox(1, country);
        }

        public void ClickSearchCity()
        {
            var Search_City = WebDriver.FindElement(By.XPath("//*[@Id='city-search-box']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_City));
            Search_City.Click();
        }

        public void SelectCityFromList(string city)
        {
            SelectCheckBox(2, city);
        }
        public void ClickSearchCompany()
        {
            var Search_Company = WebDriver.FindElement(By.XPath("//*[@id='company - search - box']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_Company));
            Search_Company.Click();
        }

        public void SelectCompanyFromList(string company)
        {
            SelectCheckBox(3, company);
        }
        public void ClickSearchAssetType()
        {
            var Search_AssetType = WebDriver.FindElement(By.XPath("//*[@Id='assetClass-search-box']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_AssetType));
            Search_AssetType.Click();
        }

        public void SelectAssetTypeFromList(string assetType)
        {
            SelectCheckBox(4, assetType);
        }
        public void ClickSearchAsset()
        {
            var Search_Assets = WebDriver.FindElement(By.XPath("//*[@Id='asset-search-box']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_Assets));
            Search_Assets.Click();
        }

        public void SelectAssetFromList(string asset)
        {
            SelectCheckBox(5, asset);
        }
        public void ClickSearchUnitType()
        {
            var Search_UnitType = WebDriver.FindElement(By.XPath("//*[@Id='unitType-search-box']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_UnitType));
            Search_UnitType.Click();
        }

        public void SelectUnitTypeFromList(string unitType)
        {
            SelectCheckBox(6, unitType);
        }
        public void ClickSearchUnitSubType()
        {
            var Search_UnitSubType = WebDriver.FindElement(By.XPath("//*[@Id='unitSubType-search-box']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_UnitSubType));
            Search_UnitSubType.Click();
        }

        public void SelectSubUnitFromList(string subUnit)
        {
            SelectCheckBox(7, subUnit);
        }

        public void ClickSearchUnit()
        {
            var Search_Unit = WebDriver.FindElement(By.XPath("//*[@Id='unit-search-box']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Search_Unit));
            Search_Unit.Click();
        }

        public void SelectUnitFromList(string unit)
        {
            SelectCheckBox(8, unit);
        }

        public void ClickUnit()
        {
            var Unit = WebDriver.FindElement(By.XPath("//*[@class='k-button k-primary btn border k-group-end']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Unit));
            Unit.Click();
        }

        public void ClickApplyButton()
        {
            var Apply_Button = WebDriver.FindElement(By.XPath("//*[@class='reset-clear apply']"));
            WebDriverWait.Until(ExpectedConditions.ElementToBeClickable(Apply_Button));
            Apply_Button.Click();
        }

        public void SelectCheckBox(int divIndex, string value)
        {
            var elementCount = WebDriver.FindElements(By.XPath("//*[@id='filterPanel']/div[" + divIndex + "]/div/div/div")).Count;
            if (elementCount > 0)
            {
                for (var i = 0; i <= elementCount; i++)
                {
                    var elements = WebDriver.FindElements(By.XPath("//*[@id='filterPanel']/div[" + divIndex + "]/div/div/div[" + i + "]/div")).Count;
                    if (elements > 0)
                    {
                        for (var j = 0; j <= elements; j++)
                        {
                            var element = WebDriver.FindElement(By.XPath("//*[@id='filterPanel']/div[" + divIndex + "]/div/div/div[" + i + "]/div[" + j + "]/div"));
                            var getText = element.Text;
                            if (getText.Contains(value))
                            {
                                var selectElement = WebDriver.FindElement(By.XPath("//*[@id='filterPanel']/div[" + divIndex + "]/div/div/div[" + i + "]/div[" + j + "]/div/input"));
                                selectElement.Click();
                            }
                        }
                    }
                }
            }
        }
    }
}
