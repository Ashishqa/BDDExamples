﻿using System;
using System.Collections.Generic;
using System.Text;
using ACM.UIAutomation.Helper;
using ACM.UIAutomation.Interface.Driver;
using OpenQA.Selenium;

namespace ACM.UIAutomation.Selenium
{
    public class Driver
    {
        private static Driver driver;
        public static IWebDriver getDriver;
        private Driver()
        {

        }

        public static Driver GetDrive(Browsers browser)
        {
            if(driver==null)
            {
                driver = new Driver();
                FactoryDriver factory = new FactoryDriver();
                IDriver drivers = factory.Factory(browser);
                getDriver = drivers.GetDriver();
            }

            return driver;
        }
    }
}
