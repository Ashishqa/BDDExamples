﻿namespace ACM.UIAutomation.Helper
{
    public enum Browsers
    {
        Chrome,
        FireFox,
        Edge
    }
}
