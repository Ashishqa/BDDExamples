﻿using System;
using System.Collections.Concurrent;


namespace ACM.UIAutomation.Helper.Readers
{
    public class ExcelReader
    {
        private readonly ConcurrentDictionary<string, dynamic> dictionary = new ConcurrentDictionary<string, dynamic>();
        
               
        public ConcurrentDictionary<string, dynamic> GetExcelDataCollection(string scenarioName, string sheetName, string excelDataFilePath)
        {
            dictionary.Clear();
            try
            {
                excelDataFilePath ??= Paths.TestDataWorkbook;
                Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook excelWorkbook = excelApp.Workbooks.Add(excelDataFilePath);
                Microsoft.Office.Interop.Excel.Worksheet sheets = excelWorkbook.Sheets[sheetName] as Microsoft.Office.Interop.Excel.Worksheet;
                Microsoft.Office.Interop.Excel.Range xlsrange = sheets.UsedRange;
                var rowcount = xlsrange.Rows.Count;
                var columnCount = xlsrange.Columns.Count;
                for(var i=1;i<=rowcount;i++)
                {
                    var scenarioNames = (xlsrange.Cells[i, 1] as Microsoft.Office.Interop.Excel.Range).Value2.ToString();
                    if(scenarioNames.Equals(scenarioName))
                    {
                        for(var j=1;j<columnCount;j++)
                        {
                            if(xlsrange.Cells[1, j + 1] != null && xlsrange.Cells[i, j + 1] != null)
                            {
                                var colnam = (xlsrange.Cells[1, j + 1] as Microsoft.Office.Interop.Excel.Range).Value2.ToString();
                                var colval = (xlsrange.Cells[i, j + 1] as Microsoft.Office.Interop.Excel.Range).Value2.ToString();
                                if(string.IsNullOrWhiteSpace(colval.ToString()) && colval != null)
                                {
                                    colval = "";
                                }
                                dictionary.TryAdd(colnam, colval.ToString());
                            }
                        }
                    }
                }
                excelWorkbook.Close(0);
                excelApp.Quit();
            }
            catch(Exception )
            {

            }
            return dictionary;
        }
    }
}