﻿using System.IO;
using System.Collections.Generic;
using System.Reflection;
using System;
using System.Text.RegularExpressions;

namespace ACM.UIAutomation.Helper
{
    public class Paths
    {
        public static string BaseFolder => GetApplicationPath();
        public static string ChromeDriverPath => $@"{BaseFolder}\TestData\Drivers\";
        public static string TestDataWorkbook => $@"{BaseFolder}\TestData\Shell.ACM.UiAutomation.TestData.xls";
        public static string JsonTestDataWorkbook => $@"{BaseFolder}\TestData\Shell.ACM.UiAutomation.TestData.json";
        private static string GetApplicationPath()
        {
            return AppDomain.CurrentDomain.BaseDirectory?.Substring(0, AppDomain.CurrentDomain.BaseDirectory.Substring(
                    0,
                    AppDomain.CurrentDomain.BaseDirectory.Substring(0,
                            AppDomain.CurrentDomain.BaseDirectory
                                .Substring(0, AppDomain.CurrentDomain.BaseDirectory.LastIndexOf('\\'))
                                .LastIndexOf('\\'))
                        .LastIndexOf('\\'))
                .LastIndexOf('\\'));
        }
    }
}
