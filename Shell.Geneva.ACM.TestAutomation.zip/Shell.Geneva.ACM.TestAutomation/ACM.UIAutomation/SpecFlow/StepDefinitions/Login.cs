﻿using System;
using System.Threading.Tasks;
using ACM.UIAutomation.Interface.Reader;
using ACM.UIAutomation.Selenium;
using ACM.UIAutomation.Selenium.Pages;
using ACM.UIAutomation.SpecFlow.Hooks;
using NUnit.Framework;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;



namespace ACM.UIAutomation.SpecFlow.StepDefinitions
{
    [Binding]
    public sealed class Login : SetUp
    {

        // Step Defininations
        [Given(@"I launch the application")]
        public void GivenILaunchTheApplication()
        {
           Utilities.LaunchUrl(Connections.EndPoints.Url); 
        }


        [Given(@"I click login link")]
        public void GivenIClickLoginLink()
        {
            new LoginPage().ClickLogin();
        }

        [Given(@"I enter the following details")]
        public async Task GivenIEnterTheFollowingDetails(Table table)
        {
            await acmReference.Reader.LoadConfigurationJson("ACM.Capacity-Total-Scenario1");
            Console.WriteLine(Reader.City);

            dynamic data = table.CreateDynamicInstance();
            new LoginPage().EnterUserCredential((string)data.UserName, (string)data.Password);
        }

        [Given(@"I click login button")]
        public void GivenIClickLoginButton()
        {
            new LoginPage().ClickLoginButton();
        }

        [Then(@"I should see user Account Summary Tab")]
        public void ThenIShouldSeeUserAccountSummaryTab()
        {
            Assert.That(new LoginPage().VerifyLoginSuccessful(), Is.True);
        }
    }
}
