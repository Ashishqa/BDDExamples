﻿using System.Threading.Tasks;
using ACM.UIAutomation.Interface.Reader;
using ACM.UIAutomation.Selenium;
using ACM.UIAutomation.Selenium.Pages;
using ACM.UIAutomation.SpecFlow.Hooks;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace ACM.UIAutomation.SpecFlow.StepDefinitions
{
    [Binding]
    public sealed class AssetsCapacity : SetUp
    {
        // Step Defininations

        [Scope(Feature = "AssetCapacity")]
        [Given(@"I launch the application")]
        public void GivenILaunchTheApplication()
        {
            Utilities.LaunchUrl(Connections.EndPoints.Url);
        }
        [Given(@"I click on program menu")]
        public void GivenIClickOnProgramMenu()
        {
            new AssetCapacityPage().ClickProgramMenu();
        }

        [Then(@"I verify page title")]
        public void ThenIVerifyPageTitle()
        {
            Assert.That(new AssetCapacityPage().GetAssetCapacityText().Contains("Asset Capacity"),"Page title has not matched");
        }

        [Then(@"I click on filter")]
        public void ThenIClickOnFilter()
        {
            new AssetCapacityPage().ClickFilter();
        }

        [Then(@"I click on search country")]
        public void ThenILickOnSearchCountry()
        {
            new AssetCapacityPage().ClickSearchCountry();
        }

        [Then(@"I enter country name and select it from list")]
        public async Task ThenIEnterCountryNameAndSelectItFromList()
        {
            await acmReference.Reader.LoadConfigurationJson("ACM.Capacity-Total-Scenario1");
            new AssetCapacityPage().SelectCountryFromList(Reader.Country);
        }

        [Then(@"I click on search city")]
        public void ThenILickOnSearchCity()
        {
            new AssetCapacityPage().ClickSearchCity();
        }

        [Then(@"I enter city name and select it from list")]
        public void ThenIEnterCityNameAndSelectItFromList()
        {
            new AssetCapacityPage().SelectCityFromList(Reader.City);
        }

        [Then(@"I click on search company")]
        public void ThenILickOnSearchCompany()
        {
            new AssetCapacityPage().ClickSearchCompany();
        }

        [Then(@"I enter company name and select it from list")]
        public void ThenIEnterCompanyNameAndSelectItFromList()
        {
            new AssetCapacityPage().SelectCompanyFromList(Reader.Owners);
        }

        [Then(@"I click on search AssetType")]
        public void ThenIClickOnSearchAssetType()
        {
            new AssetCapacityPage().ClickSearchAssetType();
        }

        [Then(@"I enter AssetTypee and select it from list")]
        public void ThenIEnterAssetTypeeAndSelectItFromList()
        {
            new AssetCapacityPage().SelectAssetTypeFromList(Reader.AssetType);
        }

        [Then(@"I click on search Assets")]
        public void ThenIClickOnSearchAssets()
        {
            new AssetCapacityPage().ClickSearchAsset();
        }

        [Then(@"I enter Assets and select it from list")]
        public void ThenIEnterAssetsAndSelectItFromList()
        {
            new AssetCapacityPage().SelectAssetFromList(Reader.Assets);
        }

        [Then(@"I click on search UnitType")]
        public void ThenIClickOnSearchUnitType()
        {
            new AssetCapacityPage().ClickSearchUnitType();
        }

        [Then(@"I enter UnitType and select it from list")]
        public void ThenIEnterUnitTypeAndSelectItFromList()
        {
            new AssetCapacityPage().SelectUnitTypeFromList(Reader.UnitType);
        }

        [Then(@"I click on search UnitSubType")]
        public void ThenIClickOnSearchUnitSubType()
        {
            new AssetCapacityPage().ClickSearchUnitSubType();
        }

        [Then(@"I enter UnitSubType and select it from list")]
        public void ThenIEnterUnitSubTypeAndSelectItFromList()
        {
            new AssetCapacityPage().SelectSubUnitFromList(Reader.UnitSubType);
        }

        [Then(@"I click on search Unit")]
        public void ThenIClickOnSearchUnit()
        {
            new AssetCapacityPage().ClickSearchUnit();
        }

        [Then(@"I enter Unit and select it from list")]
        public void ThenIEnterUnitAndSelectItFromList()
        {
            new AssetCapacityPage().SelectUnitFromList(Reader.Unit);
        }

        [Then(@"I click on Apply Button")]
        public void ThenIClickOnApplyButton()
        {
            new AssetCapacityPage().ClickApplyButton();
        }

        [Then(@"I click on Unit")]
        public void ThenIClickOnUnit()
        {
            new AssetCapacityPage().ClickUnit();
        }
    }
}
