﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using ACM.UIAutomation.Interface.Reference;
using ACM.UIAutomation.Selenium;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace ACM.UIAutomation.SpecFlow.Hooks
{
    public class SetUp
    {
        public static AcmReference acmReference = new AcmReference();
    }

    [Binding]
   public sealed class Hooks
    {
        public AcmReference acmReference = new AcmReference();

        [BeforeScenario]
        public async Task TearUp()
        {
            await acmReference.Setup.Initialize(); 
            Assert.IsTrue(Driver.getDriver != null, "Browser has not launched successful");
        }

        [AfterScenario]
        public void TearDown()
        {
            Driver.getDriver.Close();
            Driver.getDriver.Quit();
        }                
    }
}
