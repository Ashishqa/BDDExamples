﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace ACM.UIAutomation.DataBase
{
    public class ExecuteDBScripts
    {
        public async Task<dynamic> OpenAsync(string connectionString)
        {
            try
            {
                var sqlConnection = new SqlConnection(connectionString);
                await sqlConnection.OpenAsync(); return sqlConnection;
            }
            catch (Exception exception)
            {
                throw new Exception("SQL connection has not created. Connection name :" + connectionString + " .Exception :" + exception);
            }
        }
        public async Task<dynamic> ExecuteSingleQuery(string connectionString, string script)
        {
            connectionString ??= "";
            try
            {
                using (SqlConnection connection = await OpenAsync(connectionString))
                {
                    return await connection.QueryAsync(script);
                }
            }
            catch (Exception exception)
            {
                throw new Exception("SQL query has not executed correctly. SQL query : " + script + " .Exception :" + exception);
            }
        }
        public async Task<dynamic> ExecuteMultipleQuery(string script, string connectionString)
        {
            connectionString ??= "";
            try
            {
                using (SqlConnection connection = await OpenAsync(connectionString))
                {
                    using (var sqlDataAdapter = new SqlDataAdapter(script, connection))
                    {
                        using (var dataSet = new DataSet())
                        {
                            sqlDataAdapter.Fill(dataSet);
                            return dataSet;
                        }
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception("SQL query has not executed correctly. SQL query : " + script + " .Exception :" + e);
            }
        }

    }
}
