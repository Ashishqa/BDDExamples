﻿using Microsoft.Extensions.Configuration;
using System.IO;
using System.Reflection;

namespace ACM.UIAutomation.Model.AppSettings
{
    public class AppSettings
    {
        private static readonly string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        private static readonly IConfiguration _configuration = new ConfigurationBuilder().AddJsonFile(path + "\\appSettings.json").Build();

        public static T GetValue<T>(string key)
        {
            return _configuration.GetValue<T>(key);
        }
    }
}
