﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ACM.UIAutomation.Model.AppSettings
{
    public class DataBase
    {
        public string DBName { get; set; } = GetDataBaseBy("DBName");
        public string DBPassword { get; set; } = GetDataBaseBy("DBPassword");

        private static string GetDataBaseBy(string DataBaseConfigKey)
        {
            return AppSettings.GetValue<string>($"DataBase:{DataBaseConfigKey}");
        }
    }
}
